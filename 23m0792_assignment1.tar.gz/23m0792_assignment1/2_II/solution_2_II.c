#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/errno.h>
#include <asm/uaccess.h>
#include <linux/fs.h>
#include <linux/signal.h>
#include <asm/pgtable.h> 
#include <linux/pid.h>
#include <linux/mm.h>


#define FIRST_MINOR 0
#define MINOR_CNT 1
#define CHANGE_PPID _IOR('q', 1, unsigned long)


static dev_t dev;
static struct class *cl;
static struct cdev c_dev;


typedef struct {
    int PID;
    int PPID;
}changePPID;

static int doom_driver_open(struct inode *inode, struct file *file) 
{
    printk(KERN_INFO "ioctl driver got opened\n");
    return 0;
}

static int doom_driver_close(struct inode *inode, struct file *file) 
{
    printk(KERN_INFO "ioctl driver got closed\n");
    return 0;
}

static long doom_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
    switch(cmd) 
    {
        case CHANGE_PPID:
        {
            changePPID p;
            struct task_struct *task,*parent, *child;
            struct list_head *pos, *trv;
            if (copy_from_user(&p, (changePPID *)arg, sizeof(changePPID))) {
                return -EFAULT;
            }
            parent = pid_task(find_get_pid(p.PPID), PIDTYPE_PID);
            child = pid_task(find_get_pid(p.PID), PIDTYPE_PID);
            
            
            task_lock(child->parent);

            // This part is taken from https://elixir.bootlin.com/linux/v6.1/source/arch/arm/mach-s3c/adc.c#L265, refrence from Bootlin
            list_for_each_safe(pos, trv, &child->parent->children) {
                task = list_entry(pos, struct task_struct, sibling);
                if (task == child) {
                    list_del(pos); // Delete the entry of child from its original parent.
                    break;
                }
            }
            task_unlock(child->parent);

           
            task_lock(parent);
            task_lock(child);
            child->parent = parent;
            list_add_tail(&child->sibling, &parent->children);  // fuction add child process to new parent process.
            task_unlock(child);
            task_unlock(parent);
            printk(KERN_INFO "Modification Successful");
            break;
        }
        default: 
            return -ENOTTY;
    }
    return 0;
}

static struct file_operations fops = {
    .open = doom_driver_open,
    .release = doom_driver_close,
    .unlocked_ioctl = doom_ioctl,
};

static int __init ioctl_init(void) {
    int ret;
    struct device *dev_ret;
    // This code is take from https://www.opensourceforu.com/2011/08/io-control-in-linux/ , Refrence given by sir in assignment.
    printk(KERN_INFO "Module ioctl_init inserted successfully\n");
    if ((ret = alloc_chrdev_region(&dev, FIRST_MINOR, MINOR_CNT, "doom_device")) < 0)
    {
        return ret;
    }
 
    cdev_init(&c_dev, &fops);
 
    if ((ret = cdev_add(&c_dev, dev, MINOR_CNT)) < 0)
    {
        return ret;
    }
     
    if (IS_ERR(cl = class_create(THIS_MODULE, "char")))
    {
        cdev_del(&c_dev);
        unregister_chrdev_region(dev, MINOR_CNT);
        return PTR_ERR(cl);
    }
    if (IS_ERR(dev_ret = device_create(cl, NULL, dev, NULL, "doom_device")))
    {
        class_destroy(cl);
        cdev_del(&c_dev);
        unregister_chrdev_region(dev, MINOR_CNT);
        return PTR_ERR(dev_ret);
    }
 
    return 0;
}

static void __exit ioctl_exit(void) {
    device_destroy(cl, dev);
    class_destroy(cl);
    cdev_del(&c_dev);
    unregister_chrdev_region(dev, MINOR_CNT);
    pr_info("ioctl_driver unloaded\n");
    printk(KERN_INFO "Module ioctl_driver exited successfully\n");
}

module_init(ioctl_init);
module_exit(ioctl_exit);

MODULE_DESCRIPTION("Kernel module to change the parent of current process");
MODULE_AUTHOR("Akshay Patidar");
MODULE_LICENSE("GPL");

